package com.homeai.app

import android.os.Bundle
import android.text.InputType
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private val prefs by lazy { getSharedPreferences("homeai", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
        }
        web.webViewClient = WebViewClient()
        web.webChromeClient = WebChromeClient()
        val url = prefs.getString("url", null)
        if (url == null) askUrl() else web.loadUrl(url)
    }

    private fun askUrl() {
        val input = EditText(this).apply {
            hint = "http://192.168.1.10:8123"
            inputType = InputType.TYPE_TEXT_VARIATION_URI
            setText(prefs.getString("url", "http://"))
        }
        AlertDialog.Builder(this)
            .setTitle("Server URL")
            .setView(input)
            .setCancelable(false)
            .setPositiveButton("Connect") { _, _ ->
                val u = input.text.toString().trim()
                prefs.edit().putString("url", u).apply()
                web.loadUrl(u)
            }.show()
    }

    // Menu ke bajaye: back dabane par page peeche, URL badalne ke liye "Change URL" long-press nahi, app data clear karein.
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
